package com.example.karsanusa.data.preference

data class LoginRequest(
    val email: String,
    val password: String
)
package com.example.karsanusa.data.local.entity

data class CarouselEntity(
    val image: Int
)
